const form=document.getElementById('login-form'),password=document.getElementById('password'),toggle=document.getElementById('toggle-password'),error=document.getElementById('login-error'),submit=document.getElementById('submit-login'),label=submit.querySelector('.button-label'),spinner=submit.querySelector('.spinner'),arrow=submit.querySelector('.button-arrow');
toggle.addEventListener('click',()=>{const visible=password.type==='password';password.type=visible?'text':'password';toggle.setAttribute('aria-pressed',String(visible));toggle.setAttribute('aria-label',visible?'ซ่อนรหัสผ่าน':'แสดงรหัสผ่าน')});
for(const event of ['keydown','keyup'])password.addEventListener(event,e=>{document.getElementById('caps-lock').hidden=!e.getModifierState('CapsLock')});
password.addEventListener('blur',()=>{document.getElementById('caps-lock').hidden=true});
form.addEventListener('submit',async event=>{
 event.preventDefault();if(submit.disabled)return;error.hidden=true;submit.disabled=true;label.textContent='กำลังเข้าสู่ระบบ…';spinner.hidden=false;arrow.hidden=true;form.setAttribute('aria-busy','true');
 try{
  const response=await fetch('/auth/login',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:form.elements.username.value,password:password.value})});
  const data=await response.json();if(!response.ok)throw Error(data.error||'ไม่สามารถเข้าสู่ระบบได้ กรุณาลองใหม่');window.location.replace('/');
 }catch(e){error.textContent=e instanceof TypeError?'เชื่อมต่อระบบไม่สำเร็จ กรุณาตรวจสอบการเชื่อมต่อแล้วลองใหม่':e.message;error.hidden=false;password.focus();}
 finally{submit.disabled=false;label.textContent='เข้าสู่ระบบ';spinner.hidden=true;arrow.hidden=false;form.removeAttribute('aria-busy')}
});
