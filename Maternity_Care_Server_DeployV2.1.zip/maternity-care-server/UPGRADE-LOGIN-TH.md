# อัปเดตเป็นรุ่น 1.1.0 พร้อมหน้า Login

ใช้ชื่อผู้ใช้และรหัสผ่านที่ตั้งใน Portainer เดิมได้ ไม่ต้องสร้างฐานข้อมูลใหม่

1. สำรอง JSON จากเมนูนำเข้าข้อมูล หรือสำรอง SQLite ก่อนอัปเดต
2. แตก ZIP รุ่นนี้ในโฟลเดอร์ใหม่บนเครื่อง Build เพื่อแยก source เก่าออกจากรุ่นใหม่
3. เข้าโฟลเดอร์ `maternity-care-server` ที่มี Dockerfile ของรุ่นใหม่ แล้ว Build โดยใช้ tag ใหม่ เปลี่ยน YOUR_DOCKER_ID ให้ตรงกับ Docker Hub ของคุณ:

```bash
docker build -t YOUR_DOCKER_ID/maternity-care:1.1 .
docker push YOUR_DOCKER_ID/maternity-care:1.1
```

หากยังไม่ได้ Login Docker Hub ให้ใช้ `docker login --username YOUR_DOCKER_ID` ก่อน Push แล้วใส่ access token ที่ Terminal

4. ใน Portainer เปิด Stack เดิม → Editor → เปลี่ยน image เป็น `YOUR_DOCKER_ID/maternity-care:1.1`
5. คงค่า BASIC_AUTH_USER, BASIC_AUTH_PASSWORD, PUBLIC_ORIGIN, port mapping และ Volume เดิมไว้ อย่าสร้าง Stack หรือ Volume ใหม่เพื่อแทนฐานข้อมูลเดิม
6. กด Update the stack และให้ดึง image รุ่นใหม่จาก Private Registry ที่เชื่อมไว้
7. เปิด `http://192.168.100.192:3100` หรือ URL เดิมของคุณ จะเข้าหน้า Login โดยตรง ถ้าเคยเปิดหน้าเก่า ให้กด Ctrl+F5
8. กรอกชื่อผู้ใช้/รหัสผ่านจาก Environment ของ Stack เดิม และตรวจยอดข้อมูลหลังเข้า Dashboard

ข้อมูลใน Volume เดิมจะยังอยู่ อัปเดตนี้เพิ่มหน้า Login และระบบ Session โดยไม่เปลี่ยน schema ฐานข้อมูล หากต้องย้อนกลับ ให้เปลี่ยน image tag กลับเป็นรุ่นเดิม โดยคง Volume เดิม

ไฟล์นี้ไม่ได้ Push ไปยัง Docker Hub หรืออัปเดต GitHub ของคุณให้อัตโนมัติ หากต้องการใช้ลิงก์ดาวน์โหลด GitHub เดิม ให้แทนไฟล์ ZIP ใน GitHub ด้วยไฟล์รุ่นนี้ก่อน
