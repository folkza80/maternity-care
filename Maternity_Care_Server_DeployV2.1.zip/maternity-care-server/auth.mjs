import {createHash,randomBytes,timingSafeEqual} from 'node:crypto';
const hash=value=>createHash('sha256').update(value).digest();
const COOKIE='maternity_session',TTL=8*60*60*1000;
export function createAuth(username,password){
 const expected=hash(username+':'+password),sessions=new Map(),attempts=new Map();
 const token=req=>{const part=(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith(COOKIE+'='));return part?.slice(COOKIE.length+1)||''};
 function prune(){const now=Date.now();for(const [key,expiry] of sessions)if(expiry<=now)sessions.delete(key);for(const [key,value] of attempts)if(value.until<=now)attempts.delete(key);}
 return {
  authenticated(req){const key=hash(token(req)).toString('hex'),expires=sessions.get(key);if(!expires)return false;if(expires<=Date.now()){sessions.delete(key);return false}return true},
  login(req,user,pass,secure){
   prune();const ip=req.socket.remoteAddress||'unknown',failure=attempts.get(ip);
   if(failure&&failure.count>=10)return {status:429,error:'ลองเข้าสู่ระบบหลายครั้งเกินไป กรุณารอ 1 นาทีแล้วลองใหม่'};
   if(!timingSafeEqual(expected,hash(String(user)+':'+String(pass)))){
    if(!failure&&attempts.size>=5000)attempts.delete(attempts.keys().next().value);
    attempts.set(ip,{count:(failure?.count||0)+1,until:failure?.until||Date.now()+60000});
    return {status:401,error:'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'};
   }
   attempts.delete(ip);if(sessions.size>=5000)sessions.delete(sessions.keys().next().value);
   const value=randomBytes(32).toString('hex');sessions.delete(hash(token(req)).toString('hex'));sessions.set(hash(value).toString('hex'),Date.now()+TTL);
   return {status:200,cookie:`${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${TTL/1000}${secure?'; Secure':''}`};
  },
  logout(req,secure){sessions.delete(hash(token(req)).toString('hex'));return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure?'; Secure':''}`}
 };
}
