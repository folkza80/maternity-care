import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createAuth} from './auth.mjs';
import * as records from './backend/api/records/route.js';
import * as imports from './backend/api/import/route.js';
import {ensureSeed,closeDatabase} from './backend/lib/store.js';
const user=process.env.BASIC_AUTH_USER,pass=process.env.BASIC_AUTH_PASSWORD;
if(!user||!pass||pass.length<12||user.includes(':')||pass==='CHANGE_THIS_PASSWORD'){console.error('Set BASIC_AUTH_USER and a BASIC_AUTH_PASSWORD of at least 12 characters.');process.exit(1)}
const auth=createAuth(user,pass),root=path.resolve('dist'),port=Number(process.env.PORT||(process.argv.includes('--port')?process.argv[process.argv.indexOf('--port')+1]:3000));
let origin=null;
if(process.env.PUBLIC_ORIGIN){try{const value=new URL(process.env.PUBLIC_ORIGIN);if(!['http:','https:'].includes(value.protocol)||value.username||value.password||value.pathname!=='/'||value.search||value.hash)throw Error();origin=value.origin}catch{console.error('PUBLIC_ORIGIN must be empty or a full http:// or https:// origin, for example http://192.168.100.192:3100.');process.exit(1)}}
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.ttf':'font/ttf','.png':'image/png','.ico':'image/x-icon'};
await ensureSeed();
async function readBody(req,limit){const chunks=[];let length=0;for await(const chunk of req){length+=chunk.length;if(length>limit){const error=Error('ไฟล์ใหญ่เกินขนาดที่กำหนด');error.status=413;throw error}chunks.push(chunk)}return Buffer.concat(chunks)}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','SAMEORIGIN');res.setHeader('Referrer-Policy','same-origin');res.setHeader('Cache-Control','no-store');
 const json=(status,body,headers={})=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8',...headers});res.end(JSON.stringify(body))};
 const redirect=location=>{res.writeHead(303,{Location:location});res.end()};
 try{
  const url=new URL(req.url,origin||'http://'+req.headers.host),secure=url.protocol==='https:';
  if(url.pathname==='/healthz'&&req.method==='GET'){json(200,{ok:true});return}
  if(url.pathname==='/auth/login'||url.pathname==='/auth/logout'){
   if(req.method!=='POST'){json(405,{error:'ไม่รองรับคำขอนี้'});return}
   if(req.headers.origin&&req.headers.origin!==url.origin){json(403,{error:'คำขอไม่ถูกต้อง กรุณาเปิดผ่าน URL ของระบบ'});return}
   if(url.pathname==='/auth/logout'){res.setHeader('Set-Cookie',auth.logout(req,secure));redirect('/login');return}
   const format=(req.headers['content-type']||'').split(';')[0],isJson=format==='application/json';
   if(!isJson&&format!=='application/x-www-form-urlencoded'){json(415,{error:'รูปแบบคำขอไม่ถูกต้อง'});return}
   let body;try{const raw=await readBody(req,16384);body=isJson?JSON.parse(raw.toString('utf8')):Object.fromEntries(new URLSearchParams(raw.toString('utf8')))}catch(error){json(error.status||400,{error:'ไม่สามารถอ่านข้อมูลเข้าสู่ระบบได้'});return}
   if(typeof body?.username!=='string'||typeof body?.password!=='string'||body.username.length>128||body.password.length>4096){json(400,{error:'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'});return}
   const result=auth.login(req,body.username,body.password,secure);
   if(result.cookie)res.setHeader('Set-Cookie',result.cookie);
   if(isJson){json(result.status,result.status===200?{ok:true,redirect:'/'}:{error:result.error},result.status===429?{'Retry-After':'60'}:{});return}
   redirect(result.status===200?'/':result.status===429?'/login?error=rate':'/login?error=credentials');return;
  }
  const authenticated=auth.authenticated(req);
  if(url.pathname==='/login'){
   if(!['GET','HEAD'].includes(req.method)){json(405,{error:'ไม่รองรับคำขอนี้'});return}
   if(authenticated){redirect('/');return}
   let html=await fs.readFile(path.join(root,'login.html'),'utf8');
   const error=url.searchParams.get('error'),message=error==='rate'?'ลองเข้าสู่ระบบหลายครั้งเกินไป กรุณารอ 1 นาทีแล้วลองใหม่':error==='credentials'?'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง':'';
   html=html.replace('<!--LOGIN_ERROR-->',message?`<p class="error" role="alert">${message}</p>`:'');
   res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; font-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
   res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(req.method==='HEAD'?undefined:html);return;
  }
  const publicAsset=['/login.css','/login.js','/fonts/Sarabun-Regular.ttf','/favicon.svg'].includes(url.pathname);
  if(!authenticated&&!publicAsset){if(url.pathname.startsWith('/api/'))json(401,{error:'เซสชันหมดอายุ กรุณาเข้าสู่ระบบอีกครั้ง',loginUrl:'/login'});else redirect('/login');return}
  if(url.pathname.startsWith('/api/')){
   const handlers=url.pathname==='/api/records'?records:url.pathname==='/api/import'?imports:null;
   const handler=handlers?.[req.method];if(!handler){json(handlers?405:404,{error:'ไม่พบการทำงานที่ร้องขอ'});return}
   const body=await readBody(req,10*1024*1024);
   const request=new Request(url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body})});
   const result=await handler(request);res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));return;
  }
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return}
  const relative=decodeURIComponent(url.pathname),file=path.resolve(root,'.'+relative);
  if(!file.startsWith(root+path.sep)&&file!==root){res.writeHead(403);res.end();return}
  const target=relative==='/'?path.join(root,'index.html'):file;
  const stat=await fs.stat(target).catch(()=>null);if(!stat?.isFile()){res.writeHead(404);res.end('Not found');return}
  res.setHeader('Content-Type',types[path.extname(target)]||'application/octet-stream');res.writeHead(200);res.end(req.method==='HEAD'?undefined:await fs.readFile(target));
 }catch(error){console.error('Request failed:',error.message);if(!res.headersSent)json(error.status||500,{error:error.status===413?'ไฟล์ใหญ่เกินขนาดที่กำหนด':'ระบบไม่สามารถดำเนินการได้'});else res.end();}
});
server.requestTimeout=30000;server.headersTimeout=15000;server.listen(port,'0.0.0.0',()=>console.log(`Maternity Care listening on port ${port}`));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{closeDatabase();process.exit(0)}));
