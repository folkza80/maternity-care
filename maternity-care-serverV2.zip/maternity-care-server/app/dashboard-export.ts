import type {Filter,Group,RecordData} from './lib/domain';
export type ExportRow={label:string;value:number|null;previous:number|null;metric:{annualOnly?:boolean}};
export type DashboardExport={title:string;filter:Filter;rows:ExportRow[];rankedRows:ExportRow[];labels:string[];series:{label:string;values:(number|null)[]}[];records:RecordData[];groups:Group[];period:string;exportedAt:string};
export function dashboardTables(data:DashboardExport){
 return {
  summary:[['ตัวชี้วัด',`ช่วงที่เลือก (${data.filter.year})`,`ช่วงเดียวกันปีก่อน (${data.filter.year-1})`,'เปลี่ยนแปลง','หมายเหตุ'],...data.rows.map(r=>[r.label,r.value,r.previous,r.value!==null&&r.previous!==null&&r.previous!==0?(r.value-r.previous)/r.previous:null,r.metric.annualOnly?'ยอดรายปี':''])],
  chart:[['ช่วงเวลา',...data.series.map(s=>s.label)],...data.labels.map((label,i)=>[label,...data.series.map(s=>s.values[i])])],
  top:[['อันดับ','ตัวชี้วัด','จำนวน'],...data.rankedRows.map((r,i)=>[i+1,r.label,r.value])],
  monthly:[['หัวข้อ','เดือน (ค.ศ.)','ปีงบประมาณ (พ.ศ.)','ตัวชี้วัด','จำนวน','หมายเหตุ'],...data.records.flatMap(r=>data.groups[r.groupId].metrics.map(m=>[data.groups[r.groupId].name,r.month,r.fiscalYear,m.label,r.values[m.key]??null,m.annualOnly?'ยอดรายปี ไม่ใช่ยอดประจำเดือน':'']))]
 };
}
export async function dashboardWorkbook(data:DashboardExport){
 const XLSX=await import('xlsx'),book=XLSX.utils.book_new(),tables=dashboardTables(data);
 const meta=[['Maternity Care — '+data.title],['ตัวกรอง',data.period],['ส่งออกเมื่อ',data.exportedAt],['คำอธิบาย','ช่องว่าง = ไม่มีข้อมูล / 0 = ไม่มีเหตุการณ์ / เปลี่ยนแปลงว่างเมื่อไม่มีฐานเปรียบเทียบหรือปีก่อนเป็น 0'],['ขอบเขต','ข้อมูลรายเดือนตามหัวข้อและตัวกรองที่เลือก; รายการย่อยอาจซ้ำกัน ไม่รวมข้ามตัวชี้วัด'],[]];
 for(const [name,values] of [['Dashboard',[...meta,...tables.summary]],['ข้อมูลกราฟ',tables.chart],...(data.rankedRows.length?[['TOP 5',tables.top]]:[]),['ข้อมูลรายเดือน',tables.monthly]] as [string,(string|number|null|undefined)[][]][]){
  const sheet=XLSX.utils.aoa_to_sheet(values);sheet['!cols']=name==='ข้อมูลรายเดือน'?[{wch:34},{wch:18},{wch:22},{wch:54},{wch:18},{wch:42}]:[{wch:54},{wch:28},{wch:32},{wch:24},{wch:32}];
  if(name==='Dashboard')data.rows.forEach((_,i)=>{const cell=sheet[XLSX.utils.encode_cell({r:meta.length+1+i,c:3})];if(cell)cell.z='0.0%'});
  XLSX.utils.book_append_sheet(book,sheet,name);
 }
 return new Blob([XLSX.write(book,{type:'array',bookType:'xlsx'})],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
const escapeHtml=(text:string)=>text.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
export async function dashboardPrintHtml(data:DashboardExport,report:HTMLElement){
 const clone=report.cloneNode(true) as HTMLElement;
 clone.querySelectorAll('.filter-bar,.toast,.error-banner,footer,.segmented,.icon-button').forEach(el=>el.remove());
 clone.querySelectorAll('.metric-select').forEach(el=>{el.textContent='ตัวชี้วัด: '+(data.series[0]?.label??'')});
 const css=Array.from(document.styleSheets).map(sheet=>{try{return Array.from(sheet.cssRules).map(rule=>rule.cssText).join('\n')}catch{return ''}}).join('\n');
 const response=await fetch('/fonts/Sarabun-Regular.ttf');if(!response.ok)throw Error('โหลดฟอนต์สำหรับรายงานไม่สำเร็จ');
 const bytes=new Uint8Array(await response.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
 return `<!doctype html><html lang="th"><head><meta charset="utf-8"><title>${escapeHtml(data.title)} — ${escapeHtml(data.period)}</title><style>${css}\n@font-face{font-family:ExportSarabun;src:url(data:font/ttf;base64,${btoa(binary)}) format('truetype')}html,body{margin:0;background:white!important;color:#172b40;font-family:ExportSarabun,sans-serif!important}body{padding:20px}.export-heading{margin-bottom:20px;border-bottom:2px solid #167e93;padding-bottom:14px}.export-heading h1{font-size:24px;margin:0 0 6px}.export-heading p{margin:4px 0;font-size:13px}.content{padding:0!important;max-width:none!important;margin:0!important}.chart-grid{display:grid!important;grid-template-columns:1.6fr 1fr!important}.period-panel{display:block!important}.kpis{display:grid!important;grid-template-columns:repeat(4,1fr)!important}.table-scroll{overflow:visible!important}table{width:100%!important;min-width:0!important}th,td{white-space:normal!important;overflow-wrap:anywhere}.chart-viewport{overflow:visible!important}.chart-viewport svg{min-width:0!important;width:100%!important;height:auto!important}.panel,.kpi{box-shadow:none!important}.panel-heading{flex-wrap:wrap}.metrics-panel{break-inside:auto}.ranking-list li{break-inside:avoid}thead{display:table-header-group}tr,.kpi,.chart-grid,.top-metrics{break-inside:avoid}.report-note{font-size:11px}@page{size:A4 landscape;margin:12mm}@media print{body{padding:0}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.panel{border:1px solid #dce4e9}.metrics-panel{margin-top:16px}} </style></head><body><header class="export-heading"><h1>Maternity Care · ${escapeHtml(data.title)}</h1><p>${escapeHtml(data.period)}</p><p>ส่งออกเมื่อ ${escapeHtml(data.exportedAt)} · ข้อมูล ณ เวลาส่งออก</p></header>${clone.outerHTML}</body></html>`;
}
export async function printDashboard(html:string){
 document.getElementById('dashboard-print-frame')?.remove();
 const frame=document.createElement('iframe');frame.id='dashboard-print-frame';frame.title='รายงาน Dashboard สำหรับพิมพ์';frame.style.cssText='position:fixed;left:-10000px;top:0;width:1200px;height:900px;border:0';
 const loaded=new Promise<void>((resolve,reject)=>{frame.onload=()=>resolve();frame.onerror=()=>reject(Error('เปิดหน้าพิมพ์ไม่สำเร็จ'))});
 frame.srcdoc=html;document.body.appendChild(frame);
 try{await loaded;await frame.contentDocument?.fonts.ready;const win=frame.contentWindow;if(!win)throw Error('ไม่สามารถเปิดหน้าพิมพ์');win.addEventListener('afterprint',()=>frame.remove(),{once:true});win.focus();win.print();}catch(error){frame.remove();throw error;}
}
