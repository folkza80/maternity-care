import {db,json,guard,ensureSeed,validated} from '../../lib/store';
export const dynamic='force-dynamic';
export async function POST(req:Request){const denied=guard(req,true);if(denied)return denied;try{
 const body=await req.json() as {records?:unknown[];mode?:string};if(!Array.isArray(body.records)||body.records.length>1200||!body.records.length)throw Error('เลือกข้อมูลตั้งแต่ 1 ถึง 1,200 รายการ');
 const records=body.records.map(validated);const ids=new Set();for(const r of records){if(ids.has(r.id))throw Error('ไฟล์มีเดือนซ้ำในกลุ่มเดียวกัน');ids.add(r.id);}
 await ensureSeed();const existing=await db().prepare('SELECT id,fiscal_year FROM monthly_records').all();const keys=new Set(existing.results.map((r:any)=>r.id));const replace=body.mode==='replace';if(replace){const years=new Map(existing.results.map((r:any)=>[r.id,r.fiscal_year]));for(const r of records){if(years.has(r.id)&&years.get(r.id)!==r.fiscalYear)throw Error('ไม่สามารถแก้ไขปีงบประมาณของรายการที่บันทึกแล้ว: '+r.month);}}const selected=records.filter((r:any)=>replace||!keys.has(r.id));const now=new Date().toISOString();
 const stmts=selected.map((r:any)=>db().prepare('INSERT INTO monthly_records (id,group_id,month,fiscal_year,values_json,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET values_json=excluded.values_json,updated_at=excluded.updated_at').bind(r.id,r.groupId,r.month,r.fiscalYear,JSON.stringify(r.values),now));
 // D1 batch executes the entire import atomically.
 if(stmts.length)await db().batch(stmts);
 return json({inserted:selected.filter((r:any)=>!keys.has(r.id)).length,updated:selected.filter((r:any)=>keys.has(r.id)).length,skipped:records.length-selected.length});
 }catch(e){return json({error:e instanceof Error?e.message:'นำเข้าไม่สำเร็จ'},400);}}
