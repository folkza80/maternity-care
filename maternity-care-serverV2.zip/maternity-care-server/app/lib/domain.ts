export type Metric={key:string;label:string;annualOnly?:boolean};
export type Group={id:number;name:string;sourceName:string;metrics:Metric[]};
export type RecordData={id:string;groupId:number;month:string;fiscalYear:number;values:Record<string,number|null>;updatedAt?:string};
export type Filter={year:number;month:number;quarter:number};
export function fiscalYear(month:string){const [y,m]=month.split('-').map(Number);return y+543+(m>=10?1:0);}
export function quarter(month:string){return Math.floor(((Number(month.slice(5))+2)%12)/3)+1;}
export function inPeriod(r:RecordData,f:Filter){return r.fiscalYear===f.year&&(!f.month||Number(r.month.slice(5))===f.month)&&(!f.quarter||quarter(r.month)===f.quarter);}
export function aggregate(records:RecordData[],groupId:number,metric:Metric,filter:Filter):number|null{
 if(metric.annualOnly&&(filter.month||filter.quarter))return null;
 let total=0,count=0;for(const r of records){if(r.groupId!==groupId||!inPeriod(r,filter))continue;const v=r.values[metric.key];if(typeof v==='number'){total+=v;count++;}}return count?total:null;
}
export function topMetrics<T extends {value:number|null}>(rows:T[],limit=5):T[]{
 return rows.filter(row=>row.value!==null).sort((a,b)=>b.value!-a.value!).slice(0,limit);
}
export function validateRecord(input:unknown,groups:Group[]):RecordData{
 const r=input as RecordData;if(!r||!Number.isInteger(r.groupId)||!groups[r.groupId])throw Error('กลุ่มข้อมูลไม่ถูกต้อง');
 if(typeof r.month!=='string'||!/^20\d{2}-(0[1-9]|1[0-2])$/.test(r.month))throw Error('กรุณาระบุเดือนให้ถูกต้อง');
 if(!Number.isInteger(r.fiscalYear)||r.fiscalYear<1000||r.fiscalYear>9999)throw Error('กรุณากรอกปีงบประมาณ พ.ศ. เป็นตัวเลข 4 หลัก');
 if(!r.values||typeof r.values!=='object')throw Error('ไม่พบค่าตัวชี้วัด');
 const values:Record<string,number|null>={};
 for(const m of groups[r.groupId].metrics){const v=r.values[m.key];if(v!==null&&v!==undefined&&(!Number.isSafeInteger(v)||v<0))throw Error('ตัวชี้วัดต้องเป็นจำนวนเต็มตั้งแต่ 0 ขึ้นไป');values[m.key]=v??null;}
 if(Object.values(values).every(v=>v===null))throw Error('กรอกอย่างน้อย 1 ตัวชี้วัด');
 return{id:`${r.groupId}_${r.month}`,groupId:r.groupId,month:r.month,fiscalYear:r.fiscalYear,values};
}
