import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash,timingSafeEqual} from 'node:crypto';
import * as records from './backend/api/records/route.js';
import * as imports from './backend/api/import/route.js';
import {ensureSeed,closeDatabase} from './backend/lib/store.js';
const user=process.env.BASIC_AUTH_USER,pass=process.env.BASIC_AUTH_PASSWORD;
if(!user||!pass||pass.length<12||user.includes(':')||pass==='CHANGE_THIS_PASSWORD'){console.error('Set BASIC_AUTH_USER and a BASIC_AUTH_PASSWORD of at least 12 characters.');process.exit(1)}
const expected=createHash('sha256').update(user+':'+pass).digest();
const root=path.resolve('dist'),port=Number(process.env.PORT||3000);
const origin=process.env.PUBLIC_ORIGIN?new URL(process.env.PUBLIC_ORIGIN).origin:null;
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.ttf':'font/ttf','.png':'image/png','.ico':'image/x-icon'};
await ensureSeed();
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','SAMEORIGIN');res.setHeader('Referrer-Policy','same-origin');res.setHeader('Cache-Control','no-store');
 try{
  const url=new URL(req.url,origin||'http://'+req.headers.host);
  if(url.pathname==='/healthz'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'application/json'});res.end('{"ok":true}');return}
  const auth=req.headers.authorization||'';
  const decoded=auth.startsWith('Basic ')?Buffer.from(auth.slice(6),'base64').toString('utf8'):'';
  if(!timingSafeEqual(expected,createHash('sha256').update(decoded).digest())){res.writeHead(401,{'WWW-Authenticate':'Basic realm="Maternity Care", charset="UTF-8"','Content-Type':'text/plain; charset=utf-8'});res.end('กรุณาเข้าสู่ระบบ');return}
  if(url.pathname.startsWith('/api/')){
   const handlers=url.pathname==='/api/records'?records:url.pathname==='/api/import'?imports:null;
   const handler=handlers?.[req.method];if(!handler){res.writeHead(handlers?405:404,{'Content-Type':'application/json'});res.end('{"error":"ไม่พบการทำงานที่ร้องขอ"}');return}
   const chunks=[];let length=0;for await(const chunk of req){length+=chunk.length;if(length>10*1024*1024){res.writeHead(413,{'Content-Type':'application/json'});res.end('{"error":"ไฟล์ใหญ่เกิน 10 MB"}');return}chunks.push(chunk)}
   const request=new Request(url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})});
   const result=await handler(request);res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));return;
  }
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return}
  const relative=decodeURIComponent(url.pathname),file=path.resolve(root,'.'+relative);
  if(!file.startsWith(root+path.sep)&&file!==root){res.writeHead(403);res.end();return}
  let target=relative==='/'?path.join(root,'index.html'):file;
  const stat=await fs.stat(target).catch(()=>null);if(!stat?.isFile()){res.writeHead(404);res.end('Not found');return}
  res.setHeader('Content-Type',types[path.extname(target)]||'application/octet-stream');res.writeHead(200);res.end(req.method==='HEAD'?undefined:await fs.readFile(target));
 }catch(error){console.error('Request failed:',error.message);if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json'});res.end('{"error":"ระบบไม่สามารถดำเนินการได้"}');}
});
server.requestTimeout=30000;server.headersTimeout=15000;server.listen(port,'0.0.0.0',()=>console.log(`Maternity Care listening on port ${port}`));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{closeDatabase();process.exit(0)}));
