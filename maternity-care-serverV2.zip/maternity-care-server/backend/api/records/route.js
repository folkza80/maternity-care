import { db, json, guard, readRecords, ensureSeed, validated } from '../../lib/store.js';
export const dynamic = 'force-dynamic';
export async function GET(req) { const denied = guard(req); if (denied)
    return denied; try {
    return json({ records: await readRecords() });
}
catch {
    return json({ error: 'โหลดข้อมูลไม่สำเร็จ กรุณาลองใหม่' }, 500);
} }
export async function POST(req) { const denied = guard(req, true); if (denied)
    return denied; try {
    await ensureSeed();
    const r = validated(await req.json());
    const old = await db().prepare('SELECT id FROM monthly_records WHERE id=?').bind(r.id).first();
    if (old)
        return json({ error: 'กลุ่มนี้มีข้อมูลเดือนนี้แล้ว กรุณาเปิดรายการเดิมเพื่อแก้ไข' }, 409);
    const updatedAt = new Date().toISOString();
    await db().prepare('INSERT INTO monthly_records (id,group_id,month,fiscal_year,values_json,updated_at) VALUES (?,?,?,?,?,?)').bind(r.id, r.groupId, r.month, r.fiscalYear, JSON.stringify(r.values), updatedAt).run();
    return json({ record: { ...r, updatedAt } }, 201);
}
catch (e) {
    return json({ error: e instanceof Error ? e.message : 'บันทึกไม่สำเร็จ' }, 400);
} }
export async function PUT(req) { const denied = guard(req, true); if (denied)
    return denied; try {
    const body = await req.json();
    const r = validated(body);
    if (body.id !== r.id || !body.updatedAt)
        return json({ error: 'รายการอ้างอิงไม่ถูกต้อง กรุณาโหลดข้อมูลใหม่' }, 400);
    const old = await db().prepare('SELECT fiscal_year FROM monthly_records WHERE id=?').bind(r.id).first();
    if (old && old.fiscal_year !== r.fiscalYear)
        return json({ error: 'ไม่สามารถแก้ไขปีงบประมาณของรายการที่บันทึกแล้ว' }, 409);
    const updatedAt = new Date().toISOString();
    const result = await db().prepare('UPDATE monthly_records SET values_json=?, updated_at=? WHERE id=? AND updated_at=? AND fiscal_year=?').bind(JSON.stringify(r.values), updatedAt, r.id, body.updatedAt, r.fiscalYear).run();
    if (!result.meta.changes)
        return json({ error: 'รายการนี้ถูกแก้ไขแล้ว กรุณาโหลดข้อมูลใหม่' }, 409);
    return json({ record: { ...r, updatedAt } });
}
catch (e) {
    return json({ error: e instanceof Error ? e.message : 'บันทึกไม่สำเร็จ' }, 400);
} }
export async function DELETE(req) { const denied = guard(req, true); if (denied)
    return denied; try {
    const body = await req.json();
    if (typeof body.id !== 'string' || typeof body.updatedAt !== 'string')
        return json({ error: 'ข้อมูลรายการไม่ถูกต้อง' }, 400);
    const r = await db().prepare('DELETE FROM monthly_records WHERE id=? AND updated_at=?').bind(body.id, body.updatedAt).run();
    if (!r.meta.changes)
        return json({ error: 'รายการเปลี่ยนแปลงแล้ว กรุณาโหลดใหม่' }, 409);
    return json({ ok: true });
}
catch {
    return json({ error: 'ลบข้อมูลไม่สำเร็จ' }, 400);
} }
