import path from 'node:path';
import fs from 'node:fs';
import {backupDatabase,closeDatabase} from '../backend/lib/store.js';
const directory=path.resolve(process.env.DATA_DIR||'./data','backups');fs.mkdirSync(directory,{recursive:true});const file=path.join(directory,'maternity-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite');backupDatabase(file);closeDatabase();console.log(file);
