import fs from 'node:fs/promises';
import path from 'node:path';
import ts from 'typescript';
// Compile the same validation and API handlers used by the hosted application.
for(const name of ['lib/domain.ts','api/records/route.ts','api/import/route.ts']){
 const source=await fs.readFile('app/'+name,'utf8');
 const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText
  .replace(/from (['"])(\.\.?\/[^'"]+)\1/g,(_,quote,value)=>`from ${quote}${value}.js${quote}`);
 const target='backend/'+name.replace(/\.ts$/,'.js');await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,compiled);
}
await fs.copyFile('server-store.mjs','backend/lib/store.js');
for(const name of ['groups.json','seed.json'])await fs.copyFile('app/lib/'+name,'backend/lib/'+name);
console.log('Server compiled. Start with npm start (Node.js 24+).');
