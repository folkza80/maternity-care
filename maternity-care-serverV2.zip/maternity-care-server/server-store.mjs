import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import groups from './groups.json' with {type:'json'};
import initial from './seed.json' with {type:'json'};
import {validateRecord} from './domain.js';
const directory=path.resolve(process.env.DATA_DIR||'./data');
fs.mkdirSync(directory,{recursive:true,mode:0o700});
const connection=new DatabaseSync(path.join(directory,'maternity.sqlite'));
connection.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY NOT NULL,value TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS monthly_records(id TEXT PRIMARY KEY NOT NULL,group_id INTEGER NOT NULL,month TEXT NOT NULL,fiscal_year INTEGER NOT NULL,values_json TEXT NOT NULL,updated_at TEXT NOT NULL);`);
function prepare(query){const statement=connection.prepare(query);let args=[];return {
 bind(...values){args=values;return this},
 first(){return statement.get(...args)??null},
 all(){return {results:statement.all(...args)}},
 run(){return {meta:{changes:Number(statement.run(...args).changes)}}}
};}
const adapter={prepare,batch(statements){connection.exec('BEGIN IMMEDIATE');try{const results=statements.map(s=>s.run());connection.exec('COMMIT');return results}catch(error){connection.exec('ROLLBACK');throw error}}};
export const db=()=>adapter;
export const json=(body,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export function guard(req,write=false){if(write){const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)return json({error:'คำขอไม่ถูกต้อง'},403)}return null;}
export async function ensureSeed(){
 if(prepare('SELECT value FROM app_meta WHERE key=?').bind('seed-v1').first())return;
 const now=new Date().toISOString();
 const records=process.env.SEED_DATA==='false'?[]:initial;
 adapter.batch([...records.map(r=>prepare('INSERT OR IGNORE INTO monthly_records (id,group_id,month,fiscal_year,values_json,updated_at) VALUES (?,?,?,?,?,?)').bind(r.id,r.groupId,r.month,r.fiscalYear,JSON.stringify(r.values),now)),prepare('INSERT OR IGNORE INTO app_meta (key,value) VALUES (?,?)').bind('seed-v1',now)]);
}
export async function readRecords(){await ensureSeed();return prepare('SELECT * FROM monthly_records ORDER BY month DESC,group_id').all().results.map(r=>({id:r.id,groupId:r.group_id,month:r.month,fiscalYear:r.fiscal_year,values:JSON.parse(r.values_json),updatedAt:r.updated_at}));}
export const validated=r=>validateRecord(r,groups);
export function closeDatabase(){connection.close();}
export function backupDatabase(file){connection.prepare('VACUUM INTO ?').run(path.resolve(file));}
