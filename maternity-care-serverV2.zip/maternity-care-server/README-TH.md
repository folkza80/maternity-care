# Maternity Care — ชุดติดตั้งบนเซิร์ฟเวอร์

เวอร์ชันส่งออกวันที่ 22 ตุลาคม 2569 จาก source commit 3d3548a281397284c820eac2bfbdaa75fbd7aa43

ใช้ติดตั้งบน Linux/VPS/VM/Windows Server ที่รัน Linux containers ได้ หรือใช้ Node.js 24 ขึ้นไปโดยตรง ไม่ต้องมีบัญชี ChatGPT, Cloudflare หรือฐานข้อมูลภายนอก

## ในชุดนี้มีอะไรบ้าง

- โปรแกรมที่ build แล้วใน `dist/` และ `backend/` พร้อมเปิดใช้งานโดยไม่ต้อง npm install
- Source React/TypeScript ใน `app/` และ source เซิร์ฟเวอร์ `server.mjs`, `server-store.mjs`
- Dockerfile และ Compose พร้อมพื้นที่เก็บ SQLite ถาวร
- Dashboard ทั้ง 8 เมนู, ตัวกรองปี/เดือน/ไตรมาส, กราฟ, TOP 5 ในการคลอดและภาวะแทรกซ้อนทางสูติศาสตร์
- เพิ่ม/แก้ไข/ลบ, นำเข้า Excel/JSON, ส่งออกข้อมูลทั้งหมด และ Export Dashboard เป็น Excel หรือพิมพ์/บันทึก PDF
- แก้ปีงบประมาณได้ก่อนเพิ่มรายการเท่านั้น หลังบันทึกแล้วแก้ปีไม่ได้ ทั้งหน้าจอ/API/นำเข้าแทนที่
- ตรวจฐานข้อมูลทุก 30 วินาทีเมื่อเปิดหน้าเว็บ ไม่ใช่การเชื่อมฐานข้อมูลของเว็บเดิมอัตโนมัติ
- ข้อมูลตั้งต้น 288 รายการ จากไฟล์เดิม ปีงบประมาณ 2567–2569

**ชุดนี้ไม่ได้ดึงรายการที่เพิ่ม/แก้ไขภายหลังจากเว็บเดิมมาอัตโนมัติ** ให้ย้ายด้วยไฟล์สำรอง JSON ตามหัวข้อด้านล่าง ฐานข้อมูลของเซิร์ฟเวอร์ใหม่แยกจากเว็บเดิม

## วิธีติดตั้งด้วย Docker (แนะนำ)

ต้องมี Docker Engine และ Docker Compose plugin บนเครื่องปลายทาง การ build image ใช้ไฟล์ที่เตรียมไว้แล้วและดาวน์โหลดเพียง Node.js base image จึงไม่ต้องติดตั้ง npm dependencies บนเครื่องปลายทาง

1. แตก ZIP แล้วเข้าโฟลเดอร์ `maternity-care-server`
2. สร้างไฟล์ตั้งค่า

```bash
cp .env.example .env
```

3. แก้ `.env` ตั้ง `BASIC_AUTH_USER` และ `BASIC_AUTH_PASSWORD` เป็นรหัสผ่านใหม่อย่างน้อย 12 ตัวอักษร ห้ามใช้ `CHANGE_THIS_PASSWORD` หากใช้ `$` หรืออักขระพิเศษ ให้ครอบค่ารหัสผ่านด้วย single quotes ในไฟล์ .env
4. หากต้องการย้ายข้อมูลล่าสุดจากเว็บเดิม ให้ตั้ง `SEED_DATA=false` ก่อนเปิดครั้งแรก แล้วนำเข้า JSON ภายหลัง หากต้องการข้อมูลต้นฉบับ 288 รายการ ใช้ `SEED_DATA=true`
5. เริ่มโปรแกรม

```bash
docker compose up -d --build
docker compose ps
docker compose logs --tail=50
```

เปิด `http://localhost:3000` บนเครื่องเซิร์ฟเวอร์ เบราว์เซอร์จะถามชื่อผู้ใช้และรหัสผ่านที่ตั้งไว้

ค่าเริ่มต้นผูกพอร์ตกับ `127.0.0.1` สำหรับ reverse proxy หากใช้งานตรงใน LAN ให้ตั้ง `BIND_ADDRESS=0.0.0.0` ใน .env แล้วใช้ `http://IP-SERVER:3000` หากเปลี่ยน .env ให้รัน `docker compose up -d` อีกครั้ง

ฐานข้อมูลอยู่ใน Docker named volume `maternity_data` การ restart/rebuild container ไม่ลบข้อมูล **อย่าใช้ `docker compose down -v` หากยังต้องการเก็บฐานข้อมูล**

## ตั้งโดเมนผ่าน reverse proxy

ตั้ง `PUBLIC_ORIGIN` ใน .env ให้ตรงกับ URL ที่ผู้ใช้เปิด เช่น:

```dotenv
PUBLIC_ORIGIN=https://maternity.example.com
BIND_ADDRESS=127.0.0.1
```

ตั้ง reverse proxy ให้ส่งต่อไปที่ `http://127.0.0.1:3000` ตัวอย่างส่วน location ของ Nginx:

```nginx
location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    client_max_body_size 10m;
}
```

เปิด HTTPS ที่ reverse proxy ก่อนนำไปใช้ผ่านอินเทอร์เน็ต เพราะระบบนี้ใช้ HTTP Basic Authentication และไม่ใช้ระบบล็อกอิน ChatGPT เดิม `PUBLIC_ORIGIN` ต้องเป็น origin เท่านั้น ไม่มี path เช่น /dashboard หลังโดเมน ติดตั้งโปรแกรมที่ root path `/`

## ย้ายข้อมูลล่าสุดจากเว็บเดิม

1. เปิดเว็บเดิม ไปเมนู **นำเข้าข้อมูล** → ส่วน **สำรองข้อมูล** → **ดาวน์โหลดไฟล์สำรอง** จะได้ `Maternity_Backup.json` ครบทุกเมนูและทุกปี ปุ่ม Export Dashboard มีไว้ทำรายงาน ไม่ใช่ไฟล์ย้ายฐานข้อมูล
2. ก่อนเปิดเซิร์ฟเวอร์ใหม่ครั้งแรก ตั้ง `SEED_DATA=false` เพื่อเริ่มฐานข้อมูลว่าง หากเริ่มด้วยข้อมูลตั้งต้นแล้ว ควรสำรองไว้ก่อนและใช้ฐานข้อมูลว่างใหม่เมื่อต้องการให้ตรงกับเว็บเดิมทุกแถว
3. เปิดโปรแกรมใหม่ → **นำเข้าข้อมูล** → เลือก JSON → ตรวจจำนวนรายการ → ยืนยันนำเข้า
4. ตรวจยอด/ปี/เมนูเทียบกับเว็บเดิมก่อนเริ่มใช้งานจริง
5. หลังย้ายแล้ว การเพิ่มหรือแก้ไขข้อมูลบนแต่ละเว็บจะไม่ซิงก์ถึงกัน

การนำเข้าแทนที่ข้อมูลเดิมต้องใช้ปีงบประมาณเดียวกับรายการที่บันทึกไว้ และไม่ได้ลบรายการที่ไม่มีในไฟล์

## สำรองข้อมูล

ทางง่าย: ใช้หน้า **นำเข้าข้อมูล** → **ดาวน์โหลดไฟล์สำรอง** เก็บ JSON เป็นประจำ

สำรอง SQLite ขณะโปรแกรมทำงานด้วยคำสั่งนี้ (ใช้ VACUUM INTO จึงได้ไฟล์ snapshot ที่สอดคล้องกัน):

```bash
docker compose exec maternity-care node scripts/backup.mjs
docker compose cp maternity-care:/data/backups ./backups
```

เก็บโฟลเดอร์ backups นอกเซิร์ฟเวอร์ด้วย สำหรับการคืนข้อมูล JSON ให้นำเข้าในฐานข้อมูลว่างเพื่อคืนให้ตรงทุกแถว ส่วนการคืนไฟล์ SQLite ให้หยุดโปรแกรมและสำรองฐานข้อมูลปัจจุบันก่อนแทนที่ `/data/maternity.sqlite` รวมทั้งนำไฟล์ WAL/SHM เก่าออกก่อนเริ่มใหม่ ห้ามคัดลอกทับฐานข้อมูลขณะที่โปรแกรมกำลังทำงาน

## รันโดยไม่ใช้ Docker

ติดตั้ง Node.js 24+ แล้วสร้าง .env จากตัวอย่างและแก้รหัสผ่านเช่นเดียวกับวิธี Docker ไฟล์พร้อมรันมีมาให้ครบ ไม่จำเป็นต้อง npm install

```bash
node --env-file=.env server.mjs
```

ข้อมูลจะอยู่ที่ `./data/maternity.sqlite` เปลี่ยนตำแหน่งได้ด้วย `DATA_DIR` และพอร์ตด้วย `PORT` รันจากโฟลเดอร์โปรแกรมเสมอ หากใช้ service manager ให้ตั้ง WorkingDirectory มาที่โฟลเดอร์นี้และโหลด environment จาก .env ใช้ service account ที่เขียน DATA_DIR ได้

## แก้ไข source แล้ว build ใหม่

ต้องใช้ Node.js 24+ และเชื่อมต่อ npm registry:

```bash
npm ci
npm run build
```

คำสั่งนี้สร้าง `dist/` และ `backend/` ใหม่ หลัง build จึงรัน `docker compose up -d --build` หรือ restart Node service ส่วน `server-store.mjs` จะถูกคัดลอกเป็น `backend/lib/store.js` ตอน build ไม่ควรแก้ไฟล์ใน backend โดยตรง

## ขอบเขตของเวอร์ชันนี้

- หนึ่งชุดชื่อผู้ใช้/รหัสผ่านสำหรับผู้ดูแล ไม่มีบัญชีแยกรายคนหรือสิทธิ์รายเมนู
- SQLite เหมาะกับหนึ่ง instance และพื้นที่ดิสก์ถาวร ไม่ควรให้หลาย container เขียนฐานข้อมูลไฟล์เดียวผ่าน network share
- PDF ใช้หน้าต่างพิมพ์ของเบราว์เซอร์ เลือก Save as PDF พร้อมกราฟ ส่วน Excel Dashboard มีตารางสรุป/ข้อมูลกราฟ/TOP 5/ข้อมูลรายเดือน
- ไม่รวม domain, SSL certificate หรือการติดตั้งโปรแกรมลงเครื่องปลายทางให้อัตโนมัติ
- ไม่รวมรหัสผ่าน, token, .env จริง หรือฐานข้อมูลจากระบบโฮสต์เดิม

## ผลตรวจสอบก่อนส่งออก

Build frontend/backend ผ่าน และทดสอบ HTTP server จริง: การบังคับรหัสผ่าน, HTML/ฟอนต์, ข้อมูลตั้งต้น 288 รายการ, เพิ่ม/แก้ไข/ลบ, ล็อกปีงบประมาณ, ป้องกันแก้ทับรายการเก่า, นำเข้าแบบ atomic, ป้องกันคำขอข้าม origin, สำรอง SQLite และข้อมูลคงอยู่หลัง restart ผ่านแล้ว

สภาพแวดล้อมจัดทำไม่มี Docker Engine จึงไม่ได้รัน container จริงที่นี่ ควรตรวจ `docker compose ps`, healthcheck และทดสอบเพิ่มรายการบนเซิร์ฟเวอร์ปลายทางหลังติดตั้ง
